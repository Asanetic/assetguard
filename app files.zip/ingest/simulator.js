// ingest/simulator.js — a fake GL-28 tracker that connects to the ingest
// listener over TCP and streams crafted packets, so you can test the whole
// pipeline (parse -> telemetry -> alarm engine -> alarms) without a real device.
//
// Usage:
//   node ingest/simulator.js --imei 863957075080470 --scenario disturbance
//   node ingest/simulator.js --imei 863957075080470 --scenario all --interval 1000
//
//   --imei       device IMEI (must exist in `devices`, else it's an "unknown" log)
//   --scenario   normal | disturbance | overspeed | lowbattery | geofence | all
//   --host       listener host (default 127.0.0.1)
//   --port       listener port (default 9000, or INGEST_PORT)
//   --interval   ms between packets in a loop (default 1000)
//   --count      how many packets to send then exit (default: scenario length)
//   --lat --lng  base site coordinates (default Athi River ≈ -1.5420, 37.2620)
//
// The packet field order matches app/api/apiUtils/ingest/parse.js:
//   UD,date,time,fix,lat,latH,lng,lngH,speed,angle,alt,sats,gsm,batt,
//      steps1,steps2,motionByte, nBase, area,cell,sig, mcc,mnc,delay,
//      wifiName,wifiMac,wifiSig, +memsValid,x,y,z,roll,pitch,temp
import net from "net";

// ---- args ----
function arg(name, def) {
  const i = process.argv.indexOf(`--${name}`);
  return i > -1 && process.argv[i + 1] ? process.argv[i + 1] : def;
}
const IMEI = arg("imei", "863957075080470");
const SCENARIO = String(arg("scenario", "all")).toLowerCase();
const HOST = arg("host", "127.0.0.1");
const PORT = Number(arg("port", process.env.INGEST_PORT || 9000));
const INTERVAL = Number(arg("interval", 1000));
const BASE_LAT = Number(arg("lat", -1.542));
const BASE_LNG = Number(arg("lng", 37.262));
const COUNT = arg("count", null);

// ---- packet builder ----
function pad(n, w) { return String(n).padStart(w, "0"); }
function stamp(d = new Date()) {
  const date = pad(d.getUTCDate(), 2) + pad(d.getUTCMonth() + 1, 2) + pad(d.getUTCFullYear() % 100, 2);
  const time = pad(d.getUTCHours(), 2) + pad(d.getUTCMinutes(), 2) + pad(d.getUTCSeconds(), 2);
  return { date, time };
}
// Build a UD packet. opts override the interesting fields per scenario.
function buildUD(opts = {}) {
  const {
    lat = BASE_LAT, lng = BASE_LNG, speed = 0, battery = 90,
    motionByte = "00000000", sats = 9, gsm = 80, altitude = 1650, angle = 0,
    mems = { valid: true, x: 20, y: -12, z: 1010, roll: 0.4, pitch: 0.9, temp: 30.2 },
    fix = "A",
  } = opts;
  const { date, time } = stamp();
  const latH = lat < 0 ? "S" : "N", lngH = lng < 0 ? "W" : "E";
  const memsTail = mems
    ? `,${mems.valid ? "+1" : "+0"},${mems.valid ? mems.x : 0},${mems.valid ? mems.y : 0},${mems.valid ? mems.z : 0},${mems.valid ? mems.roll : "0.0"},${mems.valid ? mems.pitch : "0.0"},${mems.temp}`
    : "";
  // head + movement + motion byte + a small LBS + mobile-net + one wifi + MEMS
  const body =
    `UD,${date},${time},${fix},${Math.abs(lat).toFixed(6)},${latH},${Math.abs(lng).toFixed(6)},${lngH},` +
    `${speed},${angle},${altitude},${sats},${gsm},${battery},0,0,${motionByte},` +
    `1,255,639,02,10256,93847880,155,` +          // nBase, area, cell, sig?, mcc, mnc, delay
    `HomeWiFi,F4:2A:7D:50:DD:C6,-87` +            // one Wi-Fi entry
    memsTail;
  const len = pad(body.length.toString(16).toUpperCase(), 4);
  return `[3G*${IMEI}*${len}*${body}]`;
}

// ---- scenarios ----
// Each entry is a packet the pipeline should turn into the expected alarm.
function scenarioPackets(name) {
  const far = { lat: BASE_LAT + 0.02, lng: BASE_LNG + 0.02 };   // ≈ 3 km away
  const map = {
    normal: [buildUD({})],
    disturbance: [buildUD({ motionByte: "00100008" })],          // doc disturbance code
    overspeed: [buildUD({ speed: 92 })],                         // > 60 km/h, at site
    lowbattery: [buildUD({ battery: 12 })],                      // <= 20%
    geofence: [buildUD({ lat: far.lat, lng: far.lng, speed: 40 })],
  };
  if (name === "all") {
    return [
      buildUD({}),                                   // normal baseline
      buildUD({ motionByte: "00100008" }),           // DISTURBANCE
      buildUD({ speed: 92 }),                        // CRITICAL_MOTION
      buildUD({ battery: 12 }),                      // LOW_BATTERY
      buildUD({ lat: far.lat, lng: far.lng, speed: 40 }), // GEOFENCE_EXIT
      buildUD({ mems: { valid: false, temp: 28.5 } }),    // MEMS-invalid packet
    ];
  }
  return map[name] || map.normal;
}

// ---- run ----
const packets = scenarioPackets(SCENARIO);
const total = COUNT ? Number(COUNT) : packets.length;
const sock = net.createConnection({ host: HOST, port: PORT }, () => {
  console.log(`[sim] connected to ${HOST}:${PORT} as IMEI ${IMEI} — scenario "${SCENARIO}"`);
  let i = 0;
  const tick = () => {
    if (i >= total) {
      console.log(`[sim] sent ${total} packet(s). Closing in 1s…`);
      setTimeout(() => sock.end(), 1000);
      return;
    }
    const p = packets[i % packets.length];
    sock.write(p);
    console.log(`[sim] -> ${p}`);
    i++;
    setTimeout(tick, INTERVAL);
  };
  tick();
});
sock.on("data", (d) => console.log(`[sim] <- ${d.toString("latin1").trim()}`));
sock.on("error", (e) => console.error(`[sim] error: ${e.message}`));
sock.on("close", () => { console.log("[sim] closed."); process.exit(0); });
