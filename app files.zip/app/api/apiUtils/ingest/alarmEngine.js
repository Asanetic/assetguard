// app/api/apiUtils/ingest/alarmEngine.js
// -----------------------------------------------------------------------------
// Pure, configurable alarm rules. Given one normalized telemetry object plus the
// device (and its site), it returns zero or more alarm objects. No I/O here — the
// caller persists whatever this returns, so the rules stay testable in isolation
// and new tracker protocols reuse the same engine.
//
// Thresholds come from the device's `config` JSONB (set on the View Device page),
// with sensible fallbacks so an un-configured device still alarms reasonably:
//   config.low_battery_pct          (default 20)
//   config.speed_alert_kph          (default 60)
//   config.disturbance.motion_bytes (default ["00100008","00100009"])
//   config.disturbance.mems_mg      (default 1800 — |X,Y,Z| magnitude, 0/off)
//   config.geofence.enabled         (default true)
//   config.geofence.radius_m        (default 100)
// -----------------------------------------------------------------------------

export const ALARM_TYPES = {
  DISTURBANCE: "DISTURBANCE",
  CRITICAL_MOTION: "CRITICAL_MOTION",
  LOW_BATTERY: "LOW_BATTERY",
  GEOFENCE_EXIT: "GEOFENCE_EXIT",
  DEVICE_OFFLINE: "DEVICE_OFFLINE",
};

const DEFAULTS = {
  low_battery_pct: 20,
  speed_alert_kph: 60,
  disturbance: { motion_bytes: ["00100008", "00100009"], mems_mg: 1800 },
  geofence: { enabled: true, radius_m: 100 },
};

function cfg(device) {
  const c = (device && device.config) || {};
  return {
    low_battery_pct: numOr(c.low_battery_pct, DEFAULTS.low_battery_pct),
    speed_alert_kph: numOr(c.speed_alert_kph, DEFAULTS.speed_alert_kph),
    disturbance: {
      motion_bytes: Array.isArray(c.disturbance?.motion_bytes) && c.disturbance.motion_bytes.length
        ? c.disturbance.motion_bytes.map((x) => String(x).toUpperCase())
        : DEFAULTS.disturbance.motion_bytes,
      mems_mg: numOr(c.disturbance?.mems_mg, DEFAULTS.disturbance.mems_mg),
    },
    geofence: {
      enabled: c.geofence?.enabled !== false,
      radius_m: numOr(c.geofence?.radius_m, DEFAULTS.geofence.radius_m),
    },
  };
}
function numOr(v, d) { const n = Number(v); return Number.isFinite(n) ? n : d; }

// Great-circle distance in metres.
export function haversineMeters(aLat, aLng, bLat, bLng) {
  const R = 6371000, toRad = (d) => (d * Math.PI) / 180;
  const dLat = toRad(bLat - aLat), dLng = toRad(bLng - aLng);
  const s = Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(aLat)) * Math.cos(toRad(bLat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}

function memsMagnitude(mems) {
  if (!mems || !mems.valid) return null;
  const { x, y, z } = mems;
  if ([x, y, z].some((v) => v == null)) return null;
  return Math.sqrt(x * x + y * y + z * z);
}

/**
 * @param {object} t      normalized telemetry (from parse.toTelemetry)
 * @param {object} device device row (must carry `config`, `device_id`, `id`)
 * @param {object} [site] { lat, lng } of the device's site (for geofence)
 * @returns {Array<{type,severity,message,lat,lng,value,motionByte}>}
 */
export function evaluate(t, device, site) {
  const c = cfg(device);
  const alarms = [];
  const at = { lat: t.lat ?? null, lng: t.lng ?? null };
  const name = device?.device_id || device?.imei || t.imei;

  // 1) DISTURBANCE — motion/status word match, or MEMS acceleration spike.
  const mb = t.motionByte ? String(t.motionByte).toUpperCase() : null;
  const mag = memsMagnitude(t.mems);
  const byteHit = mb && c.disturbance.motion_bytes.includes(mb);
  const memsHit = c.disturbance.mems_mg > 0 && mag != null && mag >= c.disturbance.mems_mg;
  if (byteHit || memsHit) {
    alarms.push({
      type: ALARM_TYPES.DISTURBANCE,
      severity: "critical",
      message: byteHit
        ? `Asset disturbance detected on ${name} (motion ${mb})`
        : `Asset disturbance detected on ${name} (impact ${Math.round(mag)} mg)`,
      ...at, value: byteHit ? mb : Math.round(mag), motionByte: mb,
    });
  }

  // 2) CRITICAL_MOTION / OVERSPEED
  if (t.speed != null && t.speed > c.speed_alert_kph) {
    alarms.push({
      type: ALARM_TYPES.CRITICAL_MOTION,
      severity: "critical",
      message: `Critical motion — ${name} moving at ${t.speed} km/h (limit ${c.speed_alert_kph})`,
      ...at, value: t.speed, motionByte: mb,
    });
  }

  // 3) LOW_BATTERY
  if (t.battery != null && t.battery <= c.low_battery_pct) {
    alarms.push({
      type: ALARM_TYPES.LOW_BATTERY,
      severity: t.battery <= Math.min(10, c.low_battery_pct / 2) ? "critical" : "warning",
      message: `Low battery — ${name} at ${t.battery}% (threshold ${c.low_battery_pct}%)`,
      ...at, value: t.battery, motionByte: mb,
    });
  }

  // 4) GEOFENCE_EXIT — only when we have a fix, a site location, and it's enabled.
  if (c.geofence.enabled && at.lat != null && at.lng != null &&
      site && site.lat != null && site.lng != null) {
    const dist = haversineMeters(Number(site.lat), Number(site.lng), at.lat, at.lng);
    if (dist > c.geofence.radius_m) {
      alarms.push({
        type: ALARM_TYPES.GEOFENCE_EXIT,
        severity: "warning",
        message: `Geofence exit — ${name} is ${Math.round(dist)} m from site (radius ${c.geofence.radius_m} m)`,
        ...at, value: Math.round(dist), motionByte: mb,
      });
    }
  }

  return alarms;
}

export { cfg as resolveConfig };
