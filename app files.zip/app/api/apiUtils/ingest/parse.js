// app/api/apiUtils/ingest/parse.js
// -----------------------------------------------------------------------------
// Parse the tracker wire format:  [VENDOR*IMEI*LEN(hex)*COMMAND,payload...]
// Confirmed from real samples:
//   [3G*863957075080470*006A*UD,310726,175332,A,1.541982,S,37.261975,E,0.00,248,...]
//   [3G*861045082525554*00A3*UD,010826,195602,V,0.0,N,0.0,E,0,0,0,0,88,55,0,0,
//     000000 08,2,255,460,00,10256,93847880,155,598,2147483647,43,1,01,
//     F4:2A:7D:50:DD:C6,-87,+1,60,-140,1040,-7.7,-3.3,29.6]
// UD/UD2 = location, LK = heartbeat, AL = alarm.
//
// GL-28 UD field order (after the command token), per the interpretation doc:
//   0 date   1 time   2 fix   3 lat 4 latH   5 lng 6 lngH
//   7 speed  8 angle  9 altitude  10 satellites  11 gsmSignal  12 battery
//   13 steps1  14 steps2  15 motionByte  … LBS … MCC/MNC … Wi-Fi …
//   MEMS tail (last 7 tokens, when present): +v, x, y, z, roll, pitch, temp
//
// Parsing is defensive: the head is positional, but the motion/status word,
// LBS block and MEMS tail are located by pattern so firmware variations don't
// shift everything. Every numeric field falls back to null when absent.
// -----------------------------------------------------------------------------

// Pull complete [...] frames out of a (possibly partial) buffer.
// Returns { frames: string[], rest: string } — rest is the incomplete tail.
export function extractFrames(buf) {
  const frames = [];
  let rest = buf || "";
  while (true) {
    const start = rest.indexOf("[");
    if (start < 0) { rest = ""; break; }
    const end = rest.indexOf("]", start);
    if (end < 0) { rest = rest.slice(start); break; } // wait for the rest
    frames.push(rest.slice(start, end + 1));
    rest = rest.slice(end + 1);
  }
  return { frames, rest };
}

const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : null; };
const intOf = (v) => { const n = parseInt(v, 10); return Number.isFinite(n) ? n : null; };

function signedLat(v, h) {
  const n = Math.abs(parseFloat(v));
  if (!Number.isFinite(n)) return null;
  return String(h).toUpperCase() === "S" ? -n : n;
}
function signedLng(v, h) {
  const n = Math.abs(parseFloat(v));
  if (!Number.isFinite(n)) return null;
  return String(h).toUpperCase() === "W" ? -n : n;
}

// DDMMYY + HHMMSS (UTC) -> ISO string, or null.
function buildTime(d, t) {
  if (!d || !t || d.length < 6 || t.length < 6) return null;
  const dd = +d.slice(0, 2), mm = +d.slice(2, 4), yy = +d.slice(4, 6);
  const HH = +t.slice(0, 2), MM = +t.slice(2, 4), SS = +t.slice(4, 6);
  if ([dd, mm, yy, HH, MM, SS].some((x) => Number.isNaN(x))) return null;
  const ms = Date.UTC(2000 + yy, mm - 1, dd, HH, MM, SS);
  return Number.isFinite(ms) ? new Date(ms).toISOString() : null;
}

// A device coordinate of exactly 0/0 (null island) is a "no GPS fix" marker,
// regardless of the A/V flag — treat it as no position.
function isNullIsland(lat, lng) {
  return lat != null && lng != null && Math.abs(lat) < 1e-9 && Math.abs(lng) < 1e-9;
}

// The MEMS section is the fixed 7-token tail: [+1|+0, x, y, z, roll, pitch, temp].
// Returns { mems, rest } where rest is the field list with the MEMS tail removed.
function extractMems(fields) {
  if (fields.length >= 7) {
    const head = fields[fields.length - 7];
    if (/^[+-][01]$/.test(String(head).trim())) {
      const t = fields.slice(fields.length - 7);
      const valid = String(t[0]).trim() === "+1";
      const mems = {
        valid,
        x: valid ? intOf(t[1]) : null,
        y: valid ? intOf(t[2]) : null,
        z: valid ? intOf(t[3]) : null,
        roll: valid ? num(t[4]) : null,
        pitch: valid ? num(t[5]) : null,
        temperature: num(t[6]), // temperature is reported even when MEMS is invalid
      };
      return { mems, rest: fields.slice(0, fields.length - 7) };
    }
  }
  return { mems: null, rest: fields };
}

function parseLocation(allFields) {
  // Peel the MEMS tail off first so it can't be mistaken for LBS/Wi-Fi tokens.
  const { mems, rest: fields } = extractMems(allFields);

  const [date, time, fix, lat, latH, lng, lngH, speed, angle, altitude, sats, gsm, battery] = fields;

  let latN = signedLat(lat, latH);
  let lngN = signedLng(lng, lngH);
  if (isNullIsland(latN, lngN)) { latN = null; lngN = null; }

  const out = {
    fix: fix || null,
    lat: latN,
    lng: lngN,
    speed: num(speed),
    course: intOf(angle),          // heading / angle (kept as `course` for device_logs)
    altitude: num(altitude),
    satellites: intOf(sats),
    signal: intOf(gsm),
    battery: intOf(battery),
    deviceTime: buildTime(date, time),
    motionByte: null,
    statusHex: null,
    mcc: null, mnc: null, lac: null, cellId: null,
    mems,
  };

  // Motion / status word = the first token that is 8 hex chars (spaces allowed,
  // e.g. "000000 08" -> "00000008"). Doubles as the disturbance signal.
  const hexIdx = fields.findIndex((x) => /^[0-9A-Fa-f]{6,8}(\s+[0-9A-Fa-f]{1,2})?$/.test(String(x).trim()) && String(x).replace(/\s+/g, "").length === 8);
  if (hexIdx > -1) {
    const word = String(fields[hexIdx]).replace(/\s+/g, "");
    out.motionByte = word;
    out.statusHex = word;
    // LBS cell block sits after the status word: [nBase?, .., mcc, mnc, lac, cellId, signal].
    const tail = fields.slice(hexIdx + 1);
    if (tail.length >= 6) {
      out.mcc = intOf(tail[2]); out.mnc = intOf(tail[3]);
      out.lac = intOf(tail[4]); out.cellId = intOf(tail[5]);
    }
  }
  return out;
}

// Parse one frame string -> structured record.
export function parseFrame(frame) {
  const inner = String(frame).replace(/^\[/, "").replace(/\]$/, "");
  const star = inner.split("*");
  const prefix = star[0] || "";
  const imei = star[1] || "";
  const lenHex = star[2] || "";
  const body = star.slice(3).join("*");     // "UD,310726,..." (payload has commas, not stars)
  const comma = body.split(",");
  const cmd = (comma[0] || "").toUpperCase();
  const fields = comma.slice(1);

  const rec = { prefix, imei, lenHex, cmd, fields, raw: String(frame) };
  if (cmd === "UD" || cmd === "UD2" || cmd === "AL") Object.assign(rec, parseLocation(fields));
  return rec;
}

// Build a normalized telemetry object (the shape the DB + alarm engine consume).
export function toTelemetry(rec) {
  return {
    imei: rec.imei,
    cmd: rec.cmd,
    deviceTime: rec.deviceTime ?? null,
    fix: rec.fix ?? null,
    lat: rec.lat ?? null,
    lng: rec.lng ?? null,
    speed: rec.speed ?? null,
    course: rec.course ?? null,
    altitude: rec.altitude ?? null,
    satellites: rec.satellites ?? null,
    signal: rec.signal ?? null,
    battery: rec.battery ?? null,
    motionByte: rec.motionByte ?? null,
    statusHex: rec.statusHex ?? null,
    mcc: rec.mcc ?? null, mnc: rec.mnc ?? null, lac: rec.lac ?? null, cellId: rec.cellId ?? null,
    mems: rec.mems ?? null,
    raw: rec.raw,
  };
}
