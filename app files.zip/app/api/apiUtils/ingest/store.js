// app/api/apiUtils/ingest/store.js
// Resolve a parsed packet to a device + site, persist it, and raise alarms.
//   IMEI (field 2) -> devices row -> device.site_id -> sites row
// Pipeline per packet:
//   parse -> resolve device -> insert device_telemetry -> update device state
//         -> run alarm engine -> insert alarms
// Unknown IMEI -> quarantine table + flagged for the "unregistered device" view.
import { findDeviceByImei, touchDeviceLastSeen } from "../dataControl/devices.js";
import { insertDeviceLog, insertUnknownLog } from "../dataControl/deviceLogs.js";
import { insertTelemetry, updateDeviceState, getSiteLatLng, insertAlarm } from "../dataControl/telemetry.js";
import { toTelemetry } from "./parse.js";
import { evaluate } from "./alarmEngine.js";

export async function resolveAndStore(rec, ip, port) {
  const view = {
    receivedAt: new Date().toISOString(),
    imei: rec.imei, cmd: rec.cmd,
    fix: rec.fix ?? null, lat: rec.lat ?? null, lng: rec.lng ?? null,
    speed: rec.speed ?? null, course: rec.course ?? null,
    battery: rec.battery ?? null, signal: rec.signal ?? null,
    motionByte: rec.motionByte ?? null,
    deviceTime: rec.deviceTime ?? null, statusHex: rec.statusHex ?? null,
    src: `${ip || "?"}:${port || 0}`,
    deviceName: null, siteName: null, siteId: null, unknown: false,
    alarms: [],
  };

  let device = null;
  try { device = await findDeviceByImei(rec.imei); } catch (e) { /* table may be missing */ }

  if (!device) {
    try { await insertUnknownLog({ imei: rec.imei, raw: rec.raw, ip, port }); } catch {}
    view.unknown = true;
    return { unknown: true, view };
  }

  view.deviceName = device.device_id || device.imei;
  view.siteName = device.site || null;
  view.siteId = device.site_id || null;

  // Only location/alarm packets carry telemetry; heartbeats (LK) just bump last_seen.
  if (rec.cmd === "UD" || rec.cmd === "UD2" || rec.cmd === "AL") {
    const t = toTelemetry(rec);

    // 1) raw-ish log (kept for the existing Live-logs / legacy views)
    try {
      await insertDeviceLog({
        deviceId: device.id, siteId: device.site_id, imei: rec.imei,
        deviceTime: rec.deviceTime, fix: rec.fix, lat: rec.lat, lng: rec.lng,
        speed: rec.speed, course: rec.course, statusHex: rec.statusHex,
        event: rec.cmd === "AL" ? "Alarm" : null,
        mcc: rec.mcc, mnc: rec.mnc, lac: rec.lac, cellId: rec.cellId,
        raw: rec.raw, ip, port,
      });
    } catch {}

    // 2) normalized telemetry (the clean feed playback + the map read)
    let telemetryId = null;
    try { telemetryId = await insertTelemetry({ ...t, deviceId: device.id, siteId: device.site_id, ip, port }); } catch {}

    // 3) keep the device's live state fresh
    try { await updateDeviceState(device.id, t); } catch { try { await touchDeviceLastSeen(device.id); } catch {} }

    // 4) alarm engine — raise any triggered alarms
    let site = null;
    try { site = await getSiteLatLng(device.site_id); } catch {}
    let alarms = [];
    try { alarms = evaluate(t, device, site) || []; } catch {}
    for (const a of alarms) {
      try {
        const id = await insertAlarm({
          ...a, deviceId: device.id, siteId: device.site_id, imei: rec.imei, telemetryId,
        });
        view.alarms.push({ ...a, id, suppressed: id == null });
      } catch {}
    }
    return { unknown: false, view };
  }

  try { await touchDeviceLastSeen(device.id); } catch {}
  return { unknown: false, view };
}
