// app/api/apiUtils/dataControl/telemetry.js
// Writes + reads for the normalized telemetry feed and the alarms it raises.
import { query } from "../s_env/db.js";

// Insert one parsed telemetry row; returns the new id (or null on failure).
export async function insertTelemetry(r) {
  const { rows } = await query(
    `INSERT INTO device_telemetry
       (device_id, site_id, imei, device_time, fix, lat, lng, speed, course,
        altitude, satellites, signal, battery, motion_byte,
        mems_valid, mems_x, mems_y, mems_z, roll, pitch, temperature,
        mcc, mnc, lac, cell_id, raw, src_ip, src_port)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28)
     RETURNING id`,
    [
      r.deviceId, r.siteId, r.imei, r.deviceTime, r.fix, r.lat, r.lng, r.speed, r.course,
      r.altitude, r.satellites, r.signal, r.battery, r.motionByte,
      r.mems?.valid ?? null, r.mems?.x ?? null, r.mems?.y ?? null, r.mems?.z ?? null,
      r.mems?.roll ?? null, r.mems?.pitch ?? null, r.mems?.temperature ?? null,
      r.mcc, r.mnc, r.lac, r.cellId, r.raw, r.ip, r.port,
    ]
  );
  return rows[0]?.id ?? null;
}

// Keep the devices row's live state in sync with the newest telemetry.
export async function updateDeviceState(deviceId, t) {
  await query(
    `UPDATE devices SET
        last_seen = now(),
        battery   = COALESCE($2, battery),
        data_left = data_left
      WHERE id = $1`,
    [deviceId, t.battery ?? null]
  );
}

// Site coordinates for the geofence check.
export async function getSiteLatLng(siteId) {
  if (!siteId) return null;
  const { rows } = await query(`SELECT lat, lng FROM sites WHERE id = $1 LIMIT 1`, [siteId]);
  const s = rows[0];
  return s && s.lat != null && s.lng != null ? { lat: Number(s.lat), lng: Number(s.lng) } : null;
}

// Insert an alarm. The partial unique index (one open row per device+type) means
// a persisting condition won't stack a new row every second — it's a no-op until
// the current one is acknowledged/resolved.
export async function insertAlarm(a) {
  const { rows } = await query(
    `INSERT INTO alarms
       (device_id, site_id, imei, alarm_type, severity, message, lat, lng, value, telemetry_id, status, source)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'open','device')
     ON CONFLICT (device_id, alarm_type) WHERE status = 'open' DO NOTHING
     RETURNING id`,
    [a.deviceId, a.siteId, a.imei, a.type, a.severity, a.message,
     a.lat ?? null, a.lng ?? null, a.value != null ? String(a.value) : null, a.telemetryId ?? null]
  );
  return rows[0]?.id ?? null; // null = suppressed duplicate
}

// ---- reads (for the APIs) ----
export async function listTelemetry({ deviceId, imei, from, to, limit = 500 } = {}) {
  const where = [], params = [];
  if (deviceId) { params.push(deviceId); where.push(`t.device_id = $${params.length}`); }
  if (imei) { params.push(String(imei)); where.push(`t.imei = $${params.length}`); }
  if (from) { params.push(from); where.push(`t.received_at >= $${params.length}`); }
  if (to) { params.push(to); where.push(`t.received_at <= $${params.length}`); }
  params.push(Math.min(5000, Number(limit) || 500));
  const clause = where.length ? `WHERE ${where.join(" AND ")}` : "";
  const { rows } = await query(
    `SELECT t.* FROM device_telemetry t ${clause}
      ORDER BY t.received_at ASC LIMIT $${params.length}`, params);
  return rows;
}

export async function latestTelemetry(deviceId) {
  const { rows } = await query(
    `SELECT * FROM device_telemetry WHERE device_id = $1 ORDER BY received_at DESC LIMIT 1`,
    [deviceId]);
  return rows[0] || null;
}

export async function listAlarms({ status, deviceId, limit = 200 } = {}) {
  const where = [], params = [];
  if (status) { params.push(status); where.push(`a.status = $${params.length}`); }
  if (deviceId) { params.push(deviceId); where.push(`a.device_id = $${params.length}`); }
  params.push(Math.min(1000, Number(limit) || 200));
  const clause = where.length ? `WHERE ${where.join(" AND ")}` : "";
  const { rows } = await query(
    `SELECT a.*, d.device_id AS device_disp, s.name AS site
       FROM alarms a
       LEFT JOIN devices d ON d.id = a.device_id
       LEFT JOIN sites   s ON s.id = a.site_id
       ${clause}
      ORDER BY a.created_at DESC LIMIT $${params.length}`, params);
  return rows;
}

export async function countOpenAlarms() {
  const { rows } = await query(`SELECT COUNT(*)::int AS n FROM alarms WHERE status = 'open'`);
  return rows[0]?.n ?? 0;
}
