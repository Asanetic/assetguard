// app/api/mainapp/ingest/alarms/route.js
// GET   /api/mainapp/ingest/alarms?status=open&device=<id>&limit=<n>
//         -> alarms raised by the ingest engine (+ open count)
// PATCH /api/mainapp/ingest/alarms   { id, status }
//         -> acknowledge / resolve / flag false (also clears the open-dedupe)
//
// Namespaced under /ingest so it doesn't collide with the main All Alarms API.
// This reads/writes the same `alarms` table the engine populates.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { requireAdmin } from "../../../apiUtils/authUtils/session.js";
import { query } from "../../../apiUtils/s_env/db.js";
import { listAlarms, countOpenAlarms } from "../../../apiUtils/dataControl/telemetry.js";

export async function GET(request) {
  const gate = requireAdmin(request);
  if (gate.error) return gate.error;

  const { searchParams } = new URL(request.url);
  const status = searchParams.get("status") || null;
  const deviceId = searchParams.get("device") ? Number(searchParams.get("device")) : null;
  const limit = Number(searchParams.get("limit")) || 200;

  try {
    const [alarms, open] = await Promise.all([listAlarms({ status, deviceId, limit }), countOpenAlarms()]);
    return NextResponse.json({ alarms, open });
  } catch (err) {
    console.error("[ingest alarms] error", err);
    return NextResponse.json({ error: "Failed to load alarms" }, { status: 500 });
  }
}

const VALID = new Set(["open", "acknowledged", "resolved", "false"]);

export async function PATCH(request) {
  const gate = requireAdmin(request);
  if (gate.error) return gate.error;
  let body;
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Invalid body" }, { status: 400 }); }
  const id = Number(body.id);
  const status = String(body.status || "");
  if (!id || !VALID.has(status)) return NextResponse.json({ error: "id and a valid status are required" }, { status: 400 });

  try {
    await query(
      `UPDATE alarms SET status = $2,
         acknowledged_at = CASE WHEN $2 = 'acknowledged' THEN now() ELSE acknowledged_at END,
         resolved_at     = CASE WHEN $2 IN ('resolved','false') THEN now() ELSE resolved_at END
       WHERE id = $1`,
      [id, status]
    );
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("[ingest alarms PATCH] error", err);
    return NextResponse.json({ error: "Update failed" }, { status: 500 });
  }
}
