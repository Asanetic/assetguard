// ingest/server.js — standalone tracker ingest listener (production option).
// Runs as its own process, sharing the same Postgres DB as the web app.
//   Requires DATABASE_URL (and PGSSL) in the environment.
//   Start:  node ingest/server.js                 (port defaults to 9000)
//           INGEST_PORT=9000 node ingest/server.js
// Full pipeline: TCP frame -> GL-28 parse -> device_telemetry -> alarm engine
// -> alarms. Uses the SAME parser + resolver as the in-app listener.
//
// Downlink control: the device holds the TCP connection open and streams, so we
// keep a live registry of connected devices (by IMEI) and expose a small LOCAL
// HTTP control endpoint (127.0.0.1 only) so YOU decide exactly when to push a
// command to a device — it is NOT auto-sent. Examples (run on the VPS):
//   curl "http://127.0.0.1:9001/clients"                          # who's connected
//   curl "http://127.0.0.1:9001/send?imei=861045082572846&cmd=upgrade#"   # bare command
//   curl "http://127.0.0.1:9001/send?imei=861045082572846&cmd=upgrade%23&wrap=1"  # [3G*IMEI*LEN*upgrade#]
//   curl "http://127.0.0.1:9001/send?imei=ALL&cmd=upgrade#"       # every connected device
// (# is %23 when URL-encoding.)
//
// IMPORTANT: `./loadEnv.js` must be imported FIRST — it populates process.env
// from .env.local / .env before the DB pool (in db.js) is created.
import "./loadEnv.js";
import net from "net";
import http from "http";
import { extractFrames, parseFrame } from "../app/api/apiUtils/ingest/parse.js";
import { resolveAndStore } from "../app/api/apiUtils/ingest/store.js";

const PORT = Number(process.env.INGEST_PORT) || 9000;
const CONTROL_PORT = Number(process.env.INGEST_CONTROL_PORT) || 9001;
// Where the command console + control endpoints bind. Loopback only by default
// (open it over an SSH tunnel). Set INGEST_CONTROL_HOST=0.0.0.0 to expose it —
// and then ALSO set INGEST_CONTROL_TOKEN so /send and /raw require ?token=...
const CONTROL_HOST = process.env.INGEST_CONTROL_HOST || "127.0.0.1";
const CONTROL_TOKEN = process.env.INGEST_CONTROL_TOKEN || "";
// Optional auto-reply ONCE per TCP connection (first frame). OFF by default now
// that the web console is the primary sender — set INGEST_ONCONNECT_CMD to the
// EXACT bytes you want auto-sent, e.g. INGEST_ONCONNECT_CMD="[SG*IMEI*000B*TC,upgrade#]".
const ON_CONNECT_COMMAND = process.env.INGEST_ONCONNECT_CMD ?? "";
const ON_CONNECT_WRAP = process.env.INGEST_ONCONNECT_WRAP === "1";

let packets = 0, unknown = 0, errors = 0, alarms = 0;

// Compact one-line summary of a parsed frame for the terminal.
function summarize(rec) {
  const parts = [`imei=${rec.imei || "?"}`, `cmd=${rec.cmd || "?"}`];
  if (rec.cmd === "UD" || rec.cmd === "UD2" || rec.cmd === "AL") {
    parts.push(`fix=${rec.fix || "?"}`);
    if (rec.lat != null && rec.lng != null) parts.push(`pos=${rec.lat},${rec.lng}`);
    else if (rec.networkLocated) parts.push(`pos=LBS/WiFi`);
    else parts.push(`pos=none`);
    if (rec.speed != null) parts.push(`spd=${rec.speed}`);
    if (rec.battery != null) parts.push(`batt=${rec.battery}%`);
    if (rec.signal != null) parts.push(`gsm=${rec.signal}`);
    if (rec.satellites != null) parts.push(`sats=${rec.satellites}`);
    if (rec.steps != null) parts.push(`steps=${rec.steps}`);
    if (rec.motionByte) parts.push(`status=${rec.motionByte}`);
    if (rec.status?.disturbance) parts.push(`DISTURBANCE`);
    if (rec.status?.lowBattery) parts.push(`low-batt`);
    if (rec.mems?.valid && rec.mems?.dynamic != null) parts.push(`mems=${rec.mems.dynamic}mg`);
    if (rec.deviceTime) parts.push(`t=${rec.deviceTime}`);
  }
  return parts.join(" ");
}

// Live registry of connected devices: imei -> socket (last connection wins).
const clients = new Map();

// Send a BARE command (no wrapper) — e.g. "upgrade#" goes out exactly as typed.
function sendRaw(socket, text) {
  try { socket.write(Buffer.from(text, "latin1")); console.log(`[ingest] -> (raw) ${text}`); return true; }
  catch (e) { console.error(`[ingest] raw write failed: ${e.message}`); return false; }
}
// Send a WRAPPED GL-28 downlink: [3G*IMEI*LEN*payload], LEN = hex byte-length.
function sendWrapped(socket, prefix, imei, payload) {
  const len = Buffer.byteLength(payload, "latin1").toString(16).toUpperCase().padStart(4, "0");
  const frame = `[${prefix || "3G"}*${imei}*${len}*${payload}]`;
  try { socket.write(Buffer.from(frame, "latin1")); console.log(`[ingest] -> ${frame}`); return true; }
  catch (e) { console.error(`[ingest] downlink write failed: ${e.message}`); return false; }
}
// Push `cmd` to one IMEI (or ALL). wrap=true -> [3G*IMEI*LEN*cmd]; else bare cmd.
function pushCommand(imei, cmd, wrap) {
  const targets = String(imei).toUpperCase() === "ALL"
    ? [...clients.entries()]
    : (clients.has(imei) ? [[imei, clients.get(imei)]] : []);
  let sent = 0;
  for (const [im, sock] of targets) {
    const ok = wrap ? sendWrapped(sock, sock.__prefix || "3G", im, cmd) : sendRaw(sock, cmd);
    if (ok) sent++;
  }
  return { targets: targets.length, sent };
}

// Fail loudly if there's still no DB connection string, so the SASL "client
// password must be a string" error is explained instead of cryptic.
if (!process.env.DATABASE_URL) {
  console.error("[ingest] DATABASE_URL is not set. Add it to .env / .env.local in the app root (e.g. DATABASE_URL=postgresql://postgres:PASS@localhost:5432/assetguard) or pass it to pm2 with --update-env. Continuing, but DB writes will fail.");
} else {
  console.log(`[ingest] DATABASE_URL loaded (${String(process.env.DATABASE_URL).replace(/:\/\/([^:]+):[^@]*@/, "://$1:****@")})`);
}

const server = net.createServer((socket) => {
  socket.setEncoding("latin1");
  socket.__buf = "";
  const ip = socket.remoteAddress, sp = socket.remotePort;
  console.log(`[ingest] + connection ${ip}:${sp}`);
  socket.on("data", async (chunk) => {
    // Log the exact bytes as they arrive off the wire (before framing), so you
    // see partial/odd data too. `JSON.stringify` reveals CR/LF and control chars.
    console.log(`[ingest] <-raw ${ip}:${sp}  ${JSON.stringify(String(chunk))}`);
    socket.__buf += chunk;
    const { frames, rest } = extractFrames(socket.__buf);
    socket.__buf = rest.length > 4096 ? "" : rest;
    for (const f of frames) {
      // Log EVERY complete frame exactly as received, before parsing.
      console.log(`[ingest] <- ${ip}:${sp}  ${f}`);
      let rec;
      try { rec = parseFrame(f); }
      catch (e) { errors++; console.log(`[ingest] xx parse failed: ${e.message}  frame=${f}`); continue; }
      packets++;
      // Decoded summary of what the server understood from this frame.
      console.log(`[ingest]    parsed ${summarize(rec)}`);
      // Remember which live socket belongs to this IMEI, so the control endpoint
      // can target it while the device keeps streaming.
      if (rec.imei) { socket.__imei = rec.imei; socket.__prefix = rec.prefix; clients.set(rec.imei, socket); }

      // AUTO-REPLY on connect: send the command exactly ONCE per connection, on
      // the first frame received from this socket. This is the "reply when the
      // TCP connection is established" behaviour.
      if (ON_CONNECT_COMMAND && !socket.__cmdSent) {
        socket.__cmdSent = true;
        if (ON_CONNECT_WRAP && rec.imei) sendWrapped(socket, rec.prefix, rec.imei, ON_CONNECT_COMMAND);
        else sendRaw(socket, ON_CONNECT_COMMAND);
        console.log(`[ingest] (on-connect reply -> ${rec.imei || `${ip}:${sp}`})`);
      }

      // Heartbeat / login acknowledgements keep the device online.
      if (rec.cmd === "LK") {
        const ack = `[${rec.prefix}*${rec.imei}*0002*LK]`;
        try { socket.write(ack); console.log(`[ingest] -> (LK ack) ${ack}`); } catch {}
      }
      try {
        const { unknown: u, view } = await resolveAndStore(rec, ip, sp);
        if (u) { unknown++; console.log(`[ingest] ? unknown IMEI ${rec.imei}`); }
        else if (view?.alarms?.length) {
          for (const a of view.alarms) {
            if (!a.suppressed) { alarms++; console.log(`[ingest] ! ALARM ${a.type} (${a.severity}) — ${a.message}`); }
          }
        }
      } catch (e) { errors++; }
    }
  });
  socket.on("close", () => {
    if (socket.__imei && clients.get(socket.__imei) === socket) clients.delete(socket.__imei);
    console.log(`[ingest] - connection ${ip}:${sp}`);
  });
  socket.on("error", () => { errors++; });
});

server.listen(PORT, "0.0.0.0", () => console.log(`[ingest] listening on 0.0.0.0:${PORT}`));

// ---- web console markup (served at GET /) ---------------------------------
const UI_HTML = `<!doctype html><html><head><meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>AssetGuard · Device Console</title>
<style>
:root{--bg:#0f172a;--card:#1e293b;--line:#334155;--txt:#e2e8f0;--muted:#94a3b8;--accent:#2E6CF5;--ok:#16a34a}
*{box-sizing:border-box}
body{margin:0;font-family:system-ui,Segoe UI,Roboto,sans-serif;background:var(--bg);color:var(--txt)}
header{padding:16px 20px;border-bottom:1px solid var(--line);display:flex;align-items:center;gap:10px}
header h1{font-size:16px;margin:0;font-weight:600}
.dot{width:9px;height:9px;border-radius:50%;background:var(--muted)}
.dot.on{background:var(--ok)}
main{display:grid;grid-template-columns:290px 1fr;gap:16px;padding:16px 20px;max-width:1100px}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:14px}
h2{font-size:12px;text-transform:uppercase;letter-spacing:.05em;color:var(--muted);margin:0 0 10px}
.dev{padding:8px 10px;border:1px solid var(--line);border-radius:8px;margin-bottom:8px;cursor:pointer;font-size:13px}
.dev:hover{border-color:var(--accent)}
.dev.sel{border-color:var(--accent);background:rgba(46,108,245,.14)}
.dev .imei{font-weight:600}
.dev .meta{color:var(--muted);font-size:11px;margin-top:2px}
label{display:block;font-size:12px;color:var(--muted);margin:12px 0 4px}
input[type=text]{width:100%;padding:9px 10px;border-radius:8px;border:1px solid var(--line);background:#0b1220;color:var(--txt);font-size:14px;font-family:ui-monospace,monospace}
.modes{display:flex;gap:16px;margin-top:10px;font-size:13px;flex-wrap:wrap}
.modes label{margin:0;color:var(--txt)}
.preview{margin-top:12px;padding:10px;border-radius:8px;background:#0b1220;border:1px dashed var(--line);font-family:ui-monospace,monospace;font-size:13px;word-break:break-all;color:#7dd3fc}
button.send{margin-top:14px;background:var(--accent);color:#fff;border:0;border-radius:999px;padding:10px 22px;font-size:14px;cursor:pointer}
button.send:hover{opacity:.9}
.log{margin-top:14px;max-height:260px;overflow:auto;font-family:ui-monospace,monospace;font-size:12px}
.log .line{padding:6px 8px;border-bottom:1px solid var(--line)}
.log .ok{color:#86efac}.log .bad{color:#fca5a5}
.chips{display:flex;gap:8px;flex-wrap:wrap;margin-top:6px}
.chip{font-size:12px;padding:5px 10px;border:1px solid var(--line);border-radius:999px;cursor:pointer;color:var(--muted)}
.chip:hover{border-color:var(--accent);color:var(--txt)}
</style></head>
<body>
<header><span class="dot" id="dot"></span><h1>AssetGuard · Device Command Console</h1><span id="count" style="color:var(--muted);font-size:12px"></span></header>
<main>
<section class="card">
<h2>Connected devices</h2>
<div id="devs"></div>
<div id="empty" style="color:var(--muted);font-size:13px">No devices connected.</div>
</section>
<section class="card">
<h2>Send command</h2>
<label>Target IMEI (or ALL)</label>
<input type="text" id="imei" placeholder="861045082572846"/>
<label>Command</label>
<input type="text" id="cmd" value="upgrade#"/>
<div class="chips">
<span class="chip" data-cmd="upgrade#">upgrade#</span>
<span class="chip" data-cmd="CR#">CR#</span>
<span class="chip" data-cmd="RESET#">RESET#</span>
<span class="chip" data-cmd="FACTORY#">FACTORY#</span>
</div>
<div class="modes">
<label><input type="radio" name="mode" value="tc" checked/> TC wrapped &nbsp;[SG*IMEI*LEN*TC,cmd]</label>
<label><input type="radio" name="mode" value="raw"/> Raw exact (type full frame)</label>
</div>
<label>Bytes that will be sent</label>
<div class="preview" id="preview">—</div>
<button class="send" id="sendBtn">Send raw →</button>
<h2 style="margin-top:18px">Send log</h2>
<div class="log" id="log"></div>
</section>
</main>
<script>
var selectedPrefix="SG";var TOKEN="";
function $(id){return document.getElementById(id);}
function mode(){var r=document.querySelector('input[name=mode]:checked');return r?r.value:'tc';}
function hexLen(n){var s=n.toString(16).toUpperCase();while(s.length<4)s='0'+s;return s;}
function buildFrame(){
var imei=$('imei').value.trim()||'IMEI';
var cmd=$('cmd').value;
if(mode()==='raw')return cmd;
var payload='TC,'+cmd;
return '['+selectedPrefix+'*'+imei+'*'+hexLen(payload.length)+'*'+payload+']';
}
function refreshPreview(){$('preview').textContent=buildFrame()||'—';}
function addLog(cls,text){
var d=document.createElement('div');d.className='line '+cls;
d.textContent=new Date().toISOString().substr(11,8)+'  '+text;
var log=$('log');log.insertBefore(d,log.firstChild);
}
async function send(){
var imei=$('imei').value.trim();
if(!imei){addLog('bad','pick a device or type an IMEI first');return;}
var text=buildFrame();
var q='/raw?imei='+encodeURIComponent(imei)+'&text='+encodeURIComponent(text);
if(TOKEN)q+='&token='+encodeURIComponent(TOKEN);
try{
var r=await fetch(q);var j=await r.json();
if(j.ok)addLog('ok','SENT to '+imei+'  ('+j.sent+'/'+j.targets+')  '+text);
else addLog('bad','FAILED  '+(j.error||'unknown')+'  '+text);
}catch(e){addLog('bad','ERROR '+e.message);}
}
async function poll(){
try{
var r=await fetch('/clients');var j=await r.json();
var list=j.connected||[];
$('count').textContent=list.length+' online';
$('dot').className='dot'+(list.length?' on':'');
var wrap=$('devs');wrap.innerHTML='';
$('empty').style.display=list.length?'none':'block';
list.forEach(function(d){
var imei=(typeof d==='string')?d:d.imei;
var prefix=(typeof d==='string')?'SG':(d.prefix||'SG');
var meta=(typeof d==='string')?'':((d.ip||'')+(d.port?(':'+d.port):''));
var el=document.createElement('div');el.className='dev';
el.innerHTML='<div class="imei">'+imei+'</div><div class="meta">'+prefix+'  '+meta+'</div>';
el.onclick=function(){
$('imei').value=imei;selectedPrefix=prefix;
Array.prototype.forEach.call(document.querySelectorAll('.dev'),function(x){x.className='dev';});
el.className='dev sel';refreshPreview();
};
wrap.appendChild(el);
});
}catch(e){}
}
document.addEventListener('input',refreshPreview);
document.addEventListener('change',refreshPreview);
$('sendBtn').onclick=send;
Array.prototype.forEach.call(document.querySelectorAll('.chip'),function(c){
c.onclick=function(){$('cmd').value=c.getAttribute('data-cmd');refreshPreview();};
});
refreshPreview();poll();setInterval(poll,3000);
</script>
</body></html>`;

// Send EXACT bytes (verbatim) to one IMEI (or ALL) — powers the console.
function pushRaw(imei, text) {
  const targets = String(imei).toUpperCase() === "ALL"
    ? [...clients.entries()]
    : (clients.has(imei) ? [[imei, clients.get(imei)]] : []);
  let sent = 0;
  for (const [, sock] of targets) { if (sendRaw(sock, text)) sent++; }
  return { targets: targets.length, sent };
}

// ---- command console + control endpoints ----------------------------------
//   GET /                         -> the web console (open in a browser)
//   GET /clients                  -> [{imei,prefix,ip,port}] connected now
//   GET /send?imei=&cmd=&wrap=0|1  -> bare cmd, or GL-28 [PREFIX*IMEI*LEN*cmd]
//   GET /raw?imei=&text=          -> send the EXACT bytes given (what the UI uses)
const control = http.createServer((req, res) => {
  const url = new URL(req.url, "http://127.0.0.1");
  const send = (code, obj) => { res.writeHead(code, { "Content-Type": "application/json" }); res.end(JSON.stringify(obj)); };
  const authed = () => !CONTROL_TOKEN || url.searchParams.get("token") === CONTROL_TOKEN;

  if (url.pathname === "/" || url.pathname === "/ui") {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    return res.end(UI_HTML);
  }
  if (url.pathname === "/clients") {
    const list = [];
    for (const [imei, sock] of clients.entries())
      list.push({ imei, prefix: sock.__prefix || "SG", ip: sock.remoteAddress || null, port: sock.remotePort || null });
    return send(200, { connected: list });
  }
  if (url.pathname === "/send") {
    if (!authed()) return send(401, { error: "bad or missing token" });
    const imei = url.searchParams.get("imei") || "";
    const cmd = url.searchParams.get("cmd") || "";
    const wrap = url.searchParams.get("wrap") === "1";
    if (!imei || !cmd) return send(400, { error: "usage: /send?imei=<imei|ALL>&cmd=<text>&wrap=0|1" });
    const r = pushCommand(imei, cmd, wrap);
    if (r.targets === 0) return send(404, { error: `no connected device for imei ${imei}`, connected: [...clients.keys()] });
    return send(200, { ok: true, imei, cmd, wrap, ...r });
  }
  if (url.pathname === "/raw") {
    if (!authed()) return send(401, { error: "bad or missing token" });
    const imei = url.searchParams.get("imei") || "";
    const text = url.searchParams.get("text") || "";
    if (!imei || !text) return send(400, { error: "usage: /raw?imei=<imei|ALL>&text=<exact bytes>" });
    const r = pushRaw(imei, text);
    if (r.targets === 0) return send(404, { error: `no connected device for imei ${imei}`, connected: [...clients.keys()] });
    return send(200, { ok: true, imei, text, ...r });
  }
  send(404, { error: "not found", endpoints: ["/", "/clients", "/send?imei=&cmd=&wrap=", "/raw?imei=&text="] });
});
control.listen(CONTROL_PORT, CONTROL_HOST, () => console.log(`[ingest] command console on http://${CONTROL_HOST}:${CONTROL_PORT}  (open / in a browser)`));

setInterval(() => console.log(`[ingest] packets=${packets} alarms=${alarms} unknown=${unknown} errors=${errors} clients=${clients.size}`), 30000);
