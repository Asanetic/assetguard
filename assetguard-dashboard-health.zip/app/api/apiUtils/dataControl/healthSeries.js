// app/api/apiUtils/dataControl/healthSeries.js
// Two SLA time-series for the dashboard System Health section:
//
//   Platform uptime      = 100% − time the server was down (received no data).
//                          Atomic unit = an HOUR: the server is "up" for an hour
//                          if it received ≥1 inbound frame that hour.
//   Device availability  = share of installed devices that were online (reported)
//                          in the bucket, i.e. 100% − time devices were offline,
//                          across ALL installed devices.
//
// Ranges (bucket → point):
//   daily   → 24 hourly points (last 24 h)
//   weekly  → 7 daily points
//   monthly → 30 daily points
//   yearly  → 12 monthly points
import { query } from "../s_env/db.js";

const many = async (sql, params = []) => {
  try { const { rows } = await query(sql, params); return rows; }
  catch (e) { console.error("[healthSeries]", e?.message || e); return []; }
};
const num = (v) => (v == null ? 0 : Number(v));

export async function healthSeries(range = "monthly") {
  const R = ["daily", "weekly", "monthly", "yearly"].includes(range) ? range : "monthly";
  const total = await query(`SELECT count(*)::int AS n FROM devices`).then((r) => r.rows[0]?.n || 0).catch(() => 0);

  let platform = [], device = [];

  if (R === "daily") {
    platform = await many(`
      WITH cov AS (SELECT DISTINCT date_trunc('hour', received_at) h
                     FROM raw_logs WHERE direction='in' AND received_at >= date_trunc('hour', now()) - interval '23 hours')
      SELECT to_char(gs, 'HH24:00') AS t, gs AS ts, CASE WHEN c.h IS NOT NULL THEN 100 ELSE 0 END AS pct
        FROM generate_series(date_trunc('hour', now()) - interval '23 hours', date_trunc('hour', now()), interval '1 hour') gs
        LEFT JOIN cov c ON c.h = gs ORDER BY gs`);
    device = await many(`
      WITH cov AS (SELECT date_trunc('hour', COALESCE(device_time, received_at)) h, count(DISTINCT device_id) devs
                     FROM device_telemetry WHERE COALESCE(device_time, received_at) >= date_trunc('hour', now()) - interval '23 hours'
                    GROUP BY 1)
      SELECT to_char(gs, 'HH24:00') AS t, gs AS ts,
             CASE WHEN $1 = 0 THEN 0 ELSE ROUND(100.0 * COALESCE(c.devs,0) / $1, 1) END AS pct
        FROM generate_series(date_trunc('hour', now()) - interval '23 hours', date_trunc('hour', now()), interval '1 hour') gs
        LEFT JOIN cov c ON c.h = gs ORDER BY gs`, [total]);

  } else if (R === "yearly") {
    platform = await many(`
      WITH cov AS (SELECT date_trunc('month', received_at) m, count(DISTINCT date_trunc('hour', received_at)) hrs
                     FROM raw_logs WHERE direction='in' AND received_at >= date_trunc('month', now()) - interval '11 months'
                    GROUP BY 1)
      SELECT to_char(gs, 'Mon') AS t, gs AS ts,
             ROUND(100.0 * COALESCE(c.hrs,0) / (EXTRACT(day FROM (gs + interval '1 month' - interval '1 day')) * 24), 1) AS pct
        FROM generate_series(date_trunc('month', now()) - interval '11 months', date_trunc('month', now()), interval '1 month') gs
        LEFT JOIN cov c ON c.m = gs ORDER BY gs`);
    device = await many(`
      WITH cov AS (SELECT date_trunc('month', COALESCE(device_time, received_at)) m, count(DISTINCT device_id) devs
                     FROM device_telemetry WHERE COALESCE(device_time, received_at) >= date_trunc('month', now()) - interval '11 months'
                    GROUP BY 1)
      SELECT to_char(gs, 'Mon') AS t, gs AS ts,
             CASE WHEN $1 = 0 THEN 0 ELSE ROUND(100.0 * COALESCE(c.devs,0) / $1, 1) END AS pct
        FROM generate_series(date_trunc('month', now()) - interval '11 months', date_trunc('month', now()), interval '1 month') gs
        LEFT JOIN cov c ON c.m = gs ORDER BY gs`, [total]);

  } else {
    // weekly (7) or monthly (30) — daily points
    const span = R === "weekly" ? 7 : 30;
    platform = await many(`
      WITH cov AS (SELECT date_trunc('day', received_at) d, count(DISTINCT date_trunc('hour', received_at)) hrs
                     FROM raw_logs WHERE direction='in' AND received_at >= date_trunc('day', now()) - (($1 - 1) || ' days')::interval
                    GROUP BY 1)
      SELECT to_char(gs, 'Dy DD') AS t, gs AS ts, ROUND(100.0 * COALESCE(c.hrs,0) / 24, 1) AS pct
        FROM generate_series(date_trunc('day', now()) - (($1 - 1) || ' days')::interval, date_trunc('day', now()), interval '1 day') gs
        LEFT JOIN cov c ON c.d = gs ORDER BY gs`, [span]);
    device = await many(`
      WITH cov AS (SELECT date_trunc('day', COALESCE(device_time, received_at)) d, count(DISTINCT device_id) devs
                     FROM device_telemetry WHERE COALESCE(device_time, received_at) >= date_trunc('day', now()) - (($1 - 1) || ' days')::interval
                    GROUP BY 1)
      SELECT to_char(gs, 'Dy DD') AS t, gs AS ts,
             CASE WHEN $2 = 0 THEN 0 ELSE ROUND(100.0 * COALESCE(c.devs,0) / $2, 1) END AS pct
        FROM generate_series(date_trunc('day', now()) - (($1 - 1) || ' days')::interval, date_trunc('day', now()), interval '1 day') gs
        LEFT JOIN cov c ON c.d = gs ORDER BY gs`, [span, total]);
  }

  const map = (rows) => rows.map((r) => ({ t: r.t, pct: num(r.pct) }));
  const avg = (rows) => (rows.length ? Math.round((rows.reduce((a, r) => a + num(r.pct), 0) / rows.length) * 10) / 10 : 0);

  return {
    range: R,
    totalDevices: total,
    platformUptime: map(platform),
    deviceAvailability: map(device),
    summary: { platformUptime: avg(platform), deviceAvailability: avg(device) },
  };
}
