// app/mainapp/reports/components/Reports.jsx
// Operational reports (weekly / monthly / quarterly / yearly) from the prototype,
// wired to real data via /api/mainapp/reports. Uptime, incidents, availability,
// data usage, alarms, SLA compliance, false alarms, notifications, and the full
// alarm lifecycle log. Export to PDF (print) or Word (.doc).
"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import styles from "./reports.module.css";

const PERIODS = [
  { k: "weekly", label: "Weekly" },
  { k: "monthly", label: "Monthly" },
  { k: "quarterly", label: "Quarterly" },
  { k: "yearly", label: "Yearly" },
];
const SEV = { Critical: "#EF4444", High: "#F59E0B", Medium: "#2E6CF5", Low: "#94A3B8" };
function fmtEAT(v) {
  if (!v) return "—";
  try { return new Date(v).toLocaleString("en-GB", { timeZone: "Africa/Nairobi", day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" }); }
  catch { return "—"; }
}
function mins(a, b) {
  if (!a || !b) return null;
  const d = (new Date(b).getTime() - new Date(a).getTime()) / 60000;
  return d >= 0 ? Math.round(d) : null;
}

export default function Reports() {
  const [period, setPeriod] = useState("monthly");
  const [d, setD] = useState(null);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const printRef = useRef(null);

  useEffect(() => {
    let ok = true;
    setLoading(true);
    fetch(`/api/mainapp/reports?period=${period}`, { cache: "no-store" })
      .then((r) => r.json().then((j) => ({ ok: r.ok, j })))
      .then(({ ok: rok, j }) => { if (!ok) return; if (!rok) setErr(j.error || "Failed"); else { setD(j.report); setErr(""); } })
      .catch(() => ok && setErr("Network error"))
      .finally(() => ok && setLoading(false));
    return () => { ok = false; };
  }, [period]);

  function exportPdf() { window.print(); }
  function exportDoc() {
    if (!d) return;
    const html = buildDocHtml(d, period);
    const blob = new Blob(["﻿", html], { type: "application/msword" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `AssetGuard-report-${period}.doc`; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  if (loading && !d) return <div className={styles.page}><div className={styles.muted}>Building report…</div></div>;
  if (err && !d) return <div className={styles.page}><div className={styles.err}>{err}</div></div>;
  if (!d) return null;

  const K = d.kpis, I = d.incidents, V = d.devices, DT = d.data, AL = d.alarms, N = d.notif;
  const upDelta = (K.uptime - K.uptimePrev).toFixed(2);
  const dr = N.sent ? ((N.delivered / N.sent) * 100).toFixed(1) : "0.0";
  const maxTop = Math.max(1, ...d.topSites.map((t) => t.n));
  const sevSegs = [
    { v: I.critical, c: SEV.Critical }, { v: I.high, c: SEV.High },
    { v: I.medium, c: SEV.Medium }, { v: I.low, c: SEV.Low },
  ].filter((s) => s.v > 0);

  const brand = d.branding || {};
  return (
    <div className={styles.page} ref={printRef} style={{ position: "relative" }}>
      {brand.watermark && brand.logoDataUrl ? (
        <div aria-hidden style={{ position: "fixed", inset: 0, backgroundImage: `url(${brand.logoDataUrl})`, backgroundRepeat: "no-repeat", backgroundPosition: "center", backgroundSize: "48% auto", opacity: 0.05, pointerEvents: "none", zIndex: 0 }} />
      ) : null}
      <div className={styles.head}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          {brand.logoDataUrl ? <img src={brand.logoDataUrl} alt="" style={{ height: 40, width: "auto", objectFit: "contain" }} /> : null}
          <div>
            <div className={styles.title}>{brand.companyName ? `${brand.companyName} · Reports` : "Reports"}</div>
            <div className={styles.sub}>Uptime, incidents, availability, data usage and alarms{d.viewer?.criticalOnly ? " · Critical only" : ""}</div>
          </div>
        </div>
      </div>

      {/* period switch + export — inline flex so no global button rule can stack them */}
      {/* Fully inline layout + colours — no CSS-module dependency (avoids stale
          cached chunks). Period pills on the left, a flex:1 spacer, PDF/DOCX right. */}
      <div style={{ display: "flex", flexWrap: "nowrap", alignItems: "center", gap: 8, width: "100%" }}>
        {PERIODS.map((p) => {
          const on = period === p.k;
          return (
            <button key={p.k} type="button" onClick={() => setPeriod(p.k)}
              style={{ flex: "0 0 auto", width: "auto", display: "inline-flex", alignItems: "center", whiteSpace: "nowrap",
                border: `1px solid ${on ? "#2E6CF5" : "#E2E8F0"}`, background: on ? "#2E6CF5" : "#fff", color: on ? "#fff" : "#334155",
                borderRadius: 999, padding: "6px 14px", fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>
              {p.label}
            </button>
          );
        })}
        <div style={{ flex: "1 1 auto" }} />
        <button type="button" onClick={exportPdf}
          style={{ flex: "0 0 auto", width: "auto", display: "inline-flex", alignItems: "center", gap: 6, whiteSpace: "nowrap",
            border: "1px solid #E2E8F0", background: "#fff", color: "#DC2626", borderRadius: 9, padding: "6px 13px", fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>
          <i className="ti ti-file-type-pdf" /> PDF
        </button>
        <button type="button" onClick={exportDoc}
          style={{ flex: "0 0 auto", width: "auto", display: "inline-flex", alignItems: "center", gap: 6, whiteSpace: "nowrap",
            border: "1px solid #E2E8F0", background: "#fff", color: "#2E6CF5", borderRadius: 9, padding: "6px 13px", fontSize: 12, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}>
          <i className="ti ti-file-type-docx" /> DOCX
        </button>
      </div>
      <div className={styles.range}>{d.range} · compared against {d.prevRange}</div>

      {/* KPIs */}
      <div className={styles.kpis}>
        <Kpi k="PLATFORM UPTIME" v={`${K.uptime}%`} sub={`vs ${K.uptimePrev}% · ${upDelta >= 0 ? "▲" : "▼"} ${Math.abs(upDelta)} pp`} icon="ti-activity-heartbeat" color="#059669" bg="#D1FAE5" />
        <Kpi k="INCIDENTS" v={I.total} sub={`${I.critical} critical · ${I.resolved} resolved`} icon="ti-alert-triangle" color="#DC2626" bg="#FEE2E2" />
        <Kpi k="DEVICE AVAILABILITY" v={`${V.availability}%`} sub={`${V.available} of ${V.total} devices`} icon="ti-cpu" color="#2E6CF5" bg="#DBE7FE" />
        <Kpi k="DATA USED" v={`${DT.totalGb} GB`} sub={`${DT.perDeviceMb} MB / device`} icon="ti-database" color="#7C3AED" bg="#EDE9FE" />
      </div>

      <div className={styles.grid2}>
        {/* uptime */}
        <Card title="Platform uptime" note={`SLA ${d.sla.target}%`}>
          <div className={styles.upRow}>
            <Gauge value={K.uptime} target={d.sla.target} />
            <div className={styles.upLine}><Line data={d.series.reporting} color="#059669" /></div>
          </div>
          <div className={styles.chips}>
            <span>Downtime <b>{d.sla.downtimeMin} min</b></span>
            <span>Breaches <b style={{ color: d.sla.breaches ? "#DC2626" : "#059669" }}>{d.sla.breaches}</b></span>
            <span>SLA <b style={{ color: d.sla.met ? "#059669" : "#DC2626" }}>{d.sla.met ? "Met" : "Missed"}</b></span>
          </div>
        </Card>

        {/* incidents */}
        <Card title="Incidents" note="by severity">
          <BarsV data={d.series.incidents} labels={d.series.labels} color="#EF4444" />
          <div className={styles.donutRow}>
            <Donut segs={sevSegs} total={I.total} label="TOTAL" />
            <div className={styles.legend}>
              <Leg c={SEV.Critical} t="Critical" n={I.critical} />
              <Leg c={SEV.High} t="High" n={I.high} />
              <Leg c={SEV.Medium} t="Medium" n={I.medium} />
              <Leg c={SEV.Low} t="Low" n={I.low} />
              <div className={styles.mtt}>MTTA · NOC <b>{I.mttaMonitoringMin == null ? "—" : `${I.mttaMonitoringMin}m`}</b> · Security <b>{I.mttaSecurityMin == null ? "—" : `${I.mttaSecurityMin}m`}</b> · MTTR <b>{I.mttrMin == null ? "—" : `${I.mttrMin}m`}</b></div>
            </div>
          </div>
        </Card>

        {/* availability */}
        <Card title="Device availability" note="devices reporting">
          <Line data={d.series.reporting} color="#2E6CF5" tall />
          <div className={styles.chips}>
            <span>Available <b style={{ color: "#059669" }}>{V.available}</b></span>
            <span>Offline <b style={{ color: "#DC2626" }}>{V.offline}</b></span>
            <span>Maintenance <b style={{ color: "#7C3AED" }}>{V.maintenance}</b></span>
            <span>New <b>{V.newEnrolled}</b></span>
          </div>
        </Card>

        {/* data usage */}
        <Card title="Data usage" note="GB transferred">
          <BarsV data={d.series.dataGb} labels={d.series.labels} color="#7C3AED" fmt={(x) => x.toFixed(1)} />
          <div className={styles.chips}>
            <span>Messages <b>{DT.ingestMsgs.toLocaleString()}</b></span>
            <span>Peak <b>{DT.peakMsgMin}/min</b></span>
          </div>
        </Card>

        {/* alarms */}
        <Card title="Alarms" note={`avg ack ${I.mttaMin == null ? "—" : I.mttaMin + " min"}`}>
          <BarsV data={d.series.alarms} labels={d.series.labels} color="#F59E0B" />
          <div className={`${styles.ackBox} ${(I.mttaMin != null && I.mttaMin <= 5) ? styles.ackOk : styles.ackBad}`}>
            <i className="ti ti-clock-check" />
            <span>Average time to acknowledge</span>
            <b>{I.mttaMin == null ? "—" : `${I.mttaMin} min`}</b>
            <em>SLA ≤ 5m</em>
          </div>
          <div className={styles.chips}>
            <span>Ack <b>{AL.ack}</b></span>
            <span>Closed <b style={{ color: "#059669" }}>{AL.closed}</b></span>
            <span>False <b style={{ color: "#B45309" }}>{AL.falsePositive}</b></span>
          </div>
        </Card>

        {/* sites with incidents */}
        <Card title="Sites with incidents" note={`${d.topSites.length} sites`}>
          <div className={styles.siteList}>
            {d.topSites.length ? d.topSites.map((t) => (
              <div key={t.site} className={styles.barRow}>
                <span className={styles.barLbl} title={t.site}>{t.site}</span>
                <span className={styles.barTrack}><span className={styles.barFill} style={{ width: `${Math.round((t.n / maxTop) * 100)}%`, background: "#EF4444" }} /></span>
                <span className={styles.barN}>{t.n}</span>
              </div>
            )) : <div className={styles.muted}>No incidents in this period.</div>}
          </div>
        </Card>
      </div>

      {/* notifications */}
      <Card title="Notifications" note={`${dr}% delivered`}>
        <div className={styles.metrics}>
          <Metric k="Sent" v={N.sent.toLocaleString()} sub="all channels" />
          <Metric k="Delivered" v={N.delivered.toLocaleString()} sub={`${dr}%`} color="#059669" />
          <Metric k="Failed" v={N.failed.toLocaleString()} sub="not sent" color="#DC2626" />
          <Metric k="Recipients reached" v={N.delivered.toLocaleString()} sub="people alerted" color="#2E6CF5" />
        </div>
      </Card>

      {/* SLA compliance */}
      <Card title="SLA compliance" note={`${d.slaRows.filter((r) => r.met).length}/${d.slaRows.length} met`}>
        <div className={styles.tblWrap}>
          <table className={styles.tbl}>
            <thead><tr>{["SERVICE LEVEL", "TARGET", "MEASURED", "STATUS"].map((h) => <th key={h}>{h}</th>)}</tr></thead>
            <tbody>
              {d.slaRows.map((r) => (
                <tr key={r.name}>
                  <td className={styles.slaName}>{r.name}</td>
                  <td className={styles.muted2}>{r.target}</td>
                  <td><b>{r.value}</b></td>
                  <td>{r.met
                    ? <span className={`${styles.pill} ${styles.pOk}`}><i className="ti ti-check" />Met</span>
                    : <span className={`${styles.pill} ${styles.pBad}`}><i className="ti ti-alert-triangle" />Breached</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      {/* full alarm lifecycle log — raised → ack (NOC + security) → closed */}
      <Card title="Alarm full lifecycle log" note={`${d.alarmLog.length} alarms in period`}>
        <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          {d.alarmLog.length
            ? d.alarmLog.map((a) => <Lifecycle key={a.id} a={a} />)
            : <div className={styles.muted}>No alarms in this period.</div>}
        </div>
      </Card>
    </div>
  );
}

// One alarm's full lifecycle: raised → acknowledged (monitoring NOC + security,
// independently) → closed, each with who / note / timestamp, plus any photos.
function Lifecycle({ a }) {
  const steps = [{ label: "Raised", at: a.created_at, who: null, note: (a.alarm_type || "").replace(/_/g, " ") }];
  if (a.ackMonitoring) steps.push({ label: "Acknowledged · Monitoring (NOC)", at: a.ackMonitoring.at, who: a.ackMonitoring.by, note: a.ackMonitoring.note || a.ackMonitoring.finding });
  if (a.ackSecurity) steps.push({ label: "Responded · Security company", at: a.ackSecurity.at, who: a.ackSecurity.by, note: a.ackSecurity.note || a.ackSecurity.finding });
  if (a.closed_at) steps.push({ label: `Closed${a.outcome ? " · " + (a.outcome === "false" ? "false alarm" : a.outcome) : ""}`, at: a.closed_at, who: a.closed_by, note: a.note });
  const photos = (Array.isArray(a.photos) ? a.photos : []).map((p) => (typeof p === "string" ? p : (p?.url || p?.src || p?.dataUrl || ""))).filter(Boolean);
  return (
    <div style={LC.card}>
      <div style={LC.head}>
        <a href={`/mainapp/alarms/${encodeURIComponent(a.id)}`} style={LC.name}>{a.name}</a>
        <span style={{ color: SEV[a.priority] || "#64748B", fontWeight: 800, fontSize: 12 }}>● {a.priority}</span>
        <span style={LC.meta}>{a.id} · {a.site || "—"}{a.device_id ? ` · ${a.device_id}` : ""}</span>
        <span style={{ marginLeft: "auto", ...LC.status }}>{a.status}</span>
      </div>
      <div style={LC.timeline}>
        {steps.map((s, i) => (
          <div key={i} style={LC.step}>
            <span style={{ ...LC.dot, background: i === 0 ? "#EF4444" : i === steps.length - 1 && a.closed_at ? "#10B981" : "#2E6CF5" }} />
            <div style={{ flex: 1 }}>
              <div style={LC.stepLabel}>{s.label}{s.who ? <span style={LC.who}> — {s.who}</span> : null}</div>
              <div style={LC.stepTime}>{fmtEAT(s.at)}</div>
              {s.note ? <div style={LC.note}>{s.note}</div> : null}
            </div>
          </div>
        ))}
      </div>
      {photos.length ? (
        <div style={LC.photos}>
          {photos.slice(0, 8).map((src, i) => <img key={i} src={src} alt="evidence" style={LC.photo} />)}
        </div>
      ) : null}
    </div>
  );
}

const LC = {
  card: { border: "1px solid #EEF2F7", borderRadius: 10, padding: "12px 14px", background: "#fff", position: "relative", zIndex: 1 },
  head: { display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", marginBottom: 8 },
  name: { fontWeight: 800, color: "#0F274A", textDecoration: "none", fontSize: 14 },
  meta: { fontSize: 11.5, color: "#94A3B8" },
  status: { fontSize: 11, fontWeight: 800, color: "#475569", background: "#F1F5F9", borderRadius: 999, padding: "2px 10px" },
  timeline: { display: "flex", flexDirection: "column", gap: 8, paddingLeft: 4, borderLeft: "2px solid #EEF2F7", marginLeft: 4 },
  step: { display: "flex", gap: 10, alignItems: "flex-start", position: "relative", paddingLeft: 10 },
  dot: { position: "absolute", left: -6, top: 4, width: 9, height: 9, borderRadius: 999, boxShadow: "0 0 0 2px #fff" },
  stepLabel: { fontSize: 12.5, fontWeight: 700, color: "#0F274A" },
  who: { fontWeight: 600, color: "#2E6CF5" },
  stepTime: { fontSize: 11, color: "#94A3B8", marginTop: 1 },
  note: { fontSize: 12, color: "#475569", marginTop: 3, background: "#F8FAFC", border: "1px solid #F1F5F9", borderRadius: 6, padding: "4px 8px" },
  photos: { display: "flex", gap: 6, flexWrap: "wrap", marginTop: 10 },
  photo: { width: 72, height: 72, objectFit: "cover", borderRadius: 6, border: "1px solid #E2E8F0" },
};

/* ---------- small pieces ---------- */
function Kpi({ k, v, sub, icon, color, bg }) {
  return (
    <div className={styles.kpi}>
      <div><div className={styles.kpiK}>{k}</div><div className={styles.kpiV}>{v}</div><div className={styles.kpiSub}>{sub}</div></div>
      <div className={styles.kpiIcon} style={{ background: bg, color }}><i className={`ti ${icon}`} /></div>
    </div>
  );
}
function Card({ title, note, children }) {
  return (
    <div className={styles.card}>
      <div className={styles.cardHead}><span>{title}</span>{note ? <span className={styles.note}>{note}</span> : null}</div>
      <div className={styles.cardBody}>{children}</div>
    </div>
  );
}
function Metric({ k, v, sub, color }) {
  return <div className={styles.metric}><div className={styles.metricK}>{k}</div><div className={styles.metricV} style={color ? { color } : null}>{v}</div><div className={styles.metricSub}>{sub}</div></div>;
}
function Leg({ c, t, n }) {
  return <div className={styles.legRow}><span className={styles.legL}><span className={styles.dot} style={{ background: c }} />{t}</span><b>{n}</b></div>;
}

function Gauge({ value, target, size = 104 }) {
  const r = size / 2 - 9, C = 2 * Math.PI * r, pct = Math.max(0, Math.min(100, value)) / 100;
  const col = value >= target ? "#059669" : "#DC2626";
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className={styles.gauge}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="#EEF2F7" strokeWidth="9" />
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={col} strokeWidth="9" strokeLinecap="round"
        strokeDasharray={`${C * pct} ${C}`} transform={`rotate(-90 ${size / 2} ${size / 2})`} />
      <text x="50%" y="47%" textAnchor="middle" className={styles.gaugeV}>{value}%</text>
      <text x="50%" y="63%" textAnchor="middle" className={styles.gaugeT}>uptime</text>
    </svg>
  );
}
function Line({ data = [], color = "#2E6CF5", tall }) {
  const w = 300, h = tall ? 92 : 80, pad = 6;
  if (!data.length) return <div className={styles.muted}>No data.</div>;
  const max = Math.max(1, ...data), min = Math.min(0, ...data);
  const sx = (i) => pad + (i * (w - 2 * pad)) / Math.max(1, data.length - 1);
  const sy = (v) => h - pad - ((v - min) / (max - min || 1)) * (h - 2 * pad);
  const pts = data.map((v, i) => `${sx(i).toFixed(1)},${sy(v).toFixed(1)}`).join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className={styles.svgWide} preserveAspectRatio="none">
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}
function BarsV({ data = [], labels = [], color = "#2E6CF5", fmt }) {
  const max = Math.max(1, ...data);
  const show = data.length <= 16;
  return (
    <div className={styles.barsV}>
      {data.map((v, i) => (
        <div key={i} className={styles.barCol} title={`${labels[i] || ""}: ${fmt ? fmt(v) : v}`}>
          <div className={styles.barWrap}><div className={styles.bar} style={{ height: `${Math.round((v / max) * 100)}%`, background: color }} /></div>
          {show && <div className={styles.barLblX}>{labels[i]}</div>}
        </div>
      ))}
      {data.length === 0 && <div className={styles.muted}>No data.</div>}
    </div>
  );
}
function Donut({ segs = [], size = 92, total = 0, label = "" }) {
  const R = size / 2 - 8, C = 2 * Math.PI * R;
  const sum = segs.reduce((a, s) => a + s.v, 0) || 1;
  let acc = 0;
  return (
    <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className={styles.donut}>
      <circle cx={size / 2} cy={size / 2} r={R} fill="none" stroke="#F1F5F9" strokeWidth="10" />
      {segs.map((s, i) => {
        const len = (s.v / sum) * C, el = (
          <circle key={i} cx={size / 2} cy={size / 2} r={R} fill="none" stroke={s.c} strokeWidth="10"
            strokeDasharray={`${len} ${C - len}`} strokeDashoffset={-acc} transform={`rotate(-90 ${size / 2} ${size / 2})`} />
        );
        acc += len; return el;
      })}
      <text x="50%" y="47%" textAnchor="middle" className={styles.donutV}>{total}</text>
      <text x="50%" y="62%" textAnchor="middle" className={styles.donutL}>{label}</text>
    </svg>
  );
}

// Word-compatible HTML for the .doc export.
function buildDocHtml(d, period) {
  const K = d.kpis, I = d.incidents, V = d.devices, DT = d.data, AL = d.alarms, N = d.notif;
  const row = (a, b) => `<tr><td style="padding:4px 10px;border:1px solid #ccc">${a}</td><td style="padding:4px 10px;border:1px solid #ccc">${b}</td></tr>`;
  const sla = d.slaRows.map((r) => `<tr><td style="border:1px solid #ccc;padding:4px 10px">${r.name}</td><td style="border:1px solid #ccc;padding:4px 10px">${r.target}</td><td style="border:1px solid #ccc;padding:4px 10px">${r.value}</td><td style="border:1px solid #ccc;padding:4px 10px">${r.met ? "Met" : "Breached"}</td></tr>`).join("");
  const brand = d.branding || {};
  const esc = (s) => String(s == null ? "" : s).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
  const bd = "border:1px solid #ccc;padding:4px 8px";

  // Full lifecycle per alarm — a titled block with a step table + photos.
  const lifecycle = d.alarmLog.slice(0, 300).map((a) => {
    const steps = [`<tr><td style="${bd}"><b>Raised</b></td><td style="${bd}"></td><td style="${bd}">${fmtEAT(a.created_at)}</td><td style="${bd}">${esc((a.alarm_type || "").replace(/_/g, " "))}</td></tr>`];
    if (a.ackMonitoring) steps.push(`<tr><td style="${bd}"><b>Ack · Monitoring (NOC)</b></td><td style="${bd}">${esc(a.ackMonitoring.by)}</td><td style="${bd}">${fmtEAT(a.ackMonitoring.at)}</td><td style="${bd}">${esc(a.ackMonitoring.note || a.ackMonitoring.finding)}</td></tr>`);
    if (a.ackSecurity) steps.push(`<tr><td style="${bd}"><b>Responded · Security</b></td><td style="${bd}">${esc(a.ackSecurity.by)}</td><td style="${bd}">${fmtEAT(a.ackSecurity.at)}</td><td style="${bd}">${esc(a.ackSecurity.note || a.ackSecurity.finding)}</td></tr>`);
    if (a.closed_at) steps.push(`<tr><td style="${bd}"><b>Closed${a.outcome ? " · " + esc(a.outcome) : ""}</b></td><td style="${bd}">${esc(a.closed_by)}</td><td style="${bd}">${fmtEAT(a.closed_at)}</td><td style="${bd}">${esc(a.note)}</td></tr>`);
    const photos = (Array.isArray(a.photos) ? a.photos : []).map((p) => (typeof p === "string" ? p : (p?.url || p?.src || p?.dataUrl || ""))).filter(Boolean);
    const imgs = photos.length ? `<p style="margin:4px 0">${photos.slice(0, 8).map((s) => `<img src="${s}" style="height:120px;margin:2px;border:1px solid #ccc">`).join("")}</p>` : "";
    return `<h3 style="margin:14px 0 4px">${esc(a.name)} <span style="color:${SEV[a.priority] || "#555"}">(${esc(a.priority)})</span></h3>
      <p style="margin:0 0 4px;color:#555">${esc(a.id)} · ${esc(a.site || "—")}${a.device_id ? " · " + esc(a.device_id) : ""} · status ${esc(a.status)}</p>
      <table style="border-collapse:collapse;width:100%"><tr><th style="${bd}">Stage</th><th style="${bd}">By</th><th style="${bd}">When</th><th style="${bd}">Finding / note</th></tr>${steps.join("")}</table>${imgs}`;
  }).join("");

  // Watermark: a faint, centred company logo behind the whole document (Word
  // honours a positioned, low-opacity image on most viewers).
  const watermark = (brand.watermark && brand.logoDataUrl)
    ? `<div style="position:fixed;top:35%;left:20%;width:60%;opacity:0.07;z-index:-1"><img src="${brand.logoDataUrl}" style="width:100%"></div>` : "";
  const header = brand.logoDataUrl
    ? `<table style="width:100%"><tr><td style="width:70px"><img src="${brand.logoDataUrl}" style="height:56px"></td><td><h1 style="margin:0">${esc(brand.companyName || "AssetGuard")} — ${period[0].toUpperCase() + period.slice(1)} Report</h1></td></tr></table>`
    : `<h1>${esc(brand.companyName || "AssetGuard")} — ${period[0].toUpperCase() + period.slice(1)} Report</h1>`;

  return `<html><head><meta charset="utf-8"></head><body style="font-family:Arial,sans-serif;color:#0F274A">
  ${watermark}
  ${header}
  <p>${d.range} · compared against ${d.prevRange}</p>
  <h2>Summary</h2>
  <table style="border-collapse:collapse">
    ${row("Platform uptime", K.uptime + "% (prev " + K.uptimePrev + "%)")}
    ${row("Incidents", I.total + " (" + I.critical + " critical, " + I.resolved + " resolved)")}
    ${row("MTTA — Monitoring (NOC)", (I.mttaMonitoringMin ?? "—") + " min")}
    ${row("MTTA — Security company", (I.mttaSecurityMin ?? "—") + " min")}
    ${row("MTTR", (I.mttrMin ?? "—") + " min")}
    ${row("Device availability", V.availability + "% (" + V.available + " of " + V.total + ")")}
    ${row("Data used", DT.totalGb + " GB · " + DT.ingestMsgs.toLocaleString() + " messages")}
    ${row("Alarms", AL.raised + " raised, " + AL.closed + " closed, " + AL.falsePositive + " false")}
    ${row("Notifications", N.sent + " sent, " + N.delivered + " delivered, " + N.failed + " failed")}
  </table>
  <h2>SLA compliance</h2>
  <table style="border-collapse:collapse"><tr><th style="border:1px solid #ccc;padding:4px 10px">Service level</th><th style="border:1px solid #ccc;padding:4px 10px">Target</th><th style="border:1px solid #ccc;padding:4px 10px">Measured</th><th style="border:1px solid #ccc;padding:4px 10px">Status</th></tr>${sla}</table>
  <h2>Alarm full lifecycle log</h2>
  ${lifecycle || "<p>No alarms in this period.</p>"}
  </body></html>`;
}
